const axios = require("axios");
const fetch = require('node-fetch');

async function fetchGameData(url, gameId, serverId = null) {
  let fullUrl = serverId ? `${url}?userId=${gameId}&zoneId=${serverId}` : `${url}?userId=${gameId}&zoneId=undefined`;

  const response = await fetch(fullUrl)
  const data = await response.json()
  
  return data.data || "User Id not found"
}

exports.getUsernameMl = async(id, zoneId) => {
  return new Promise(async (resolve, reject) => {
    axios
    .post(
      'https://api.duniagames.co.id/api/transaction/v1/top-up/inquiry/store',
      new URLSearchParams(
        Object.entries({
          productId: '1',
          itemId: '2',
          catalogId: '57',
          paymentId: '352',
          gameId: id,
          zoneId: zoneId,
          product_ref: 'REG',
          product_ref_denom: 'AE',
        })
      ),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Referer: 'https://www.duniagames.co.id/',
          Accept: 'application/json',
        },
      }
    )
    .then((response) => {
      resolve(response.data.data.gameDetail.userName)
    })
    .catch((err) => {
      resolve("User Id not found")
    })
  })
}

exports.getUsernameFf = async(id) => {
  return new Promise(async (resolve, reject) => {
    axios
    .post(
      'https://api.duniagames.co.id/api/transaction/v1/top-up/inquiry/store',
      new URLSearchParams(
        Object.entries({
          productId: 3,
          itemId: 11,
          catalogId: 66,
          paymentId: 750,
          gameId: id,
          product_ref: 'AE',
          product_ref_denom: 'AE',
        })
      ),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Referer: 'https://www.duniagames.co.id/',
          Accept: 'application/json',
        },
      }
    )
    .then((response) => {
      resolve(response.data.data.gameDetail.userName)
    })
    .catch((err) => {
      resolve("User Id not found")
    })
  })
}

exports.getUsernameCod = async(id) => {
  return new Promise(async (resolve, reject) => {
    axios
    .post(
      'https://api.duniagames.co.id/api/transaction/v1/top-up/inquiry/store',
      new URLSearchParams(
        Object.entries({
          productId: 18,
          itemId: 88,
          catalogId: 144,
          paymentId: 828,
          gameId: id,
          product_ref: 'CMS',
          product_ref_denom: 'REG',
        })
      ),
      {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          Referer: 'https://www.duniagames.co.id/',
          Accept: 'application/json',
        },
      }
    )
    .then((response) => {
      resolve(response.data.data.gameDetail.userName)
    })
    .catch((err) => {
      resolve("User Id not found")
    })
  })
}

exports.getUsernameGi = async(id, zoneId) => {
  const url = 'https://api.vocagame.com/v1/order/prepare/genshin_impact'
  return await fetchGameData(url, id, zoneId)
}

exports.getUsernameSus = async(id) => {
  const url = 'https://api.vocagame.com/v1/order/prepare/SUPER_SUS'
  return await fetchGameData(url, id)
}

exports.getUsernameHok = async(id) => {
  const url = 'https://api.vocagame.com/v1/order/prepare/HOK'
  return await fetchGameData(url, id)
}

exports.getUsernamePubg = async(id) => {
  const url = 'https://api.vocagame.com/v1/order/prepare/PUBGM'
  return await fetchGameData(url, id)
}

exports.getUsernameAg = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/ag?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernameHsr = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/hsr?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernameHi = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/hi?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernamePb = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/pb?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernameSm = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/sm?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernameValo = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/valo?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernamePgr = async(id, zoneId) => {
  const data = fetch(`https://api.isan.eu.org/nickname/pgr?id=${id}&server=${zoneId}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernameZzz = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/zzz?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}

exports.getUsernameAov = async(id) => {
  const data = fetch(`https://api.isan.eu.org/nickname/aov?id=${id}`)
  const result = data.json()
  return result.name || "User Id not found"
}