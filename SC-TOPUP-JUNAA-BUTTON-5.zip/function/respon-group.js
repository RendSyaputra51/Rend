const moment = require('moment');

exports.groupResponseRemove = async (junaa, update) => {
  const metadata = await junaa.groupMetadata(update.id)
  for (let num of update.participants) {
    try {
      try {
        ppuser = await junaa.profilePictureUrl(num, 'image')
      } catch {
        ppuser = 'https://telegra.ph/file/265c672094dfa87caea19.jpg'
      }
      if (update.action == 'remove') {
        junaa.fetchStatus(num).then(async bio => {
          await junaa.sendMessage(update.id, { image: { url: ppuser }, caption: `*Leave From Grup ${metadata.subject}*\n\n📛 : _@${num.split("@")[0]}_\n🔢 : _${num.split("@")[0]}_\n💌 : _${bio.status ? bio.status : '-'}_\n🏅 : _${metadata.participants.length ? metadata.participants.length : "Undefined"}_\n📆 : _${moment.tz('Asia/Jakarta').format('dddd')}, ${moment.tz('Asia/Jakarta').format('DD MMMM YYYY')}_\n⏰ : _${moment.tz('Asia/Jakarta').format('HH:mm:ss')} *WIB*_\n\n*┗━━ ❑ GoodBye👋*`, mentions: [num] })
        }).catch(async err => {
          await junaa.sendMessage(update.id, { image: { url: ppuser }, caption: `*Leave From Grup ${metadata.subject}*\n\n📛 : _@${num.split("@")[0]}_\n🔢 : _${num.split("@")[0]}_\n💌 : _-_\n🏅 : _${metadata.participants.length ? metadata.participants.length : "Undefined"}_\n📆 : _${moment.tz('Asia/Jakarta').format('dddd')}, ${moment.tz('Asia/Jakarta').format('DD MMMM YYYY')}_\n⏰ : _${moment.tz('Asia/Jakarta').format('HH:mm:ss')} *WIB*_\n\n*┗━━ ❑ GoodBye👋*`, mentions: [num] })
        })
      }
    } catch (err) {
      console.log(err)
    }
  }
}

exports.groupResponseWelcome = async (junaa, update) => {
  const metadata = await junaa.groupMetadata(update.id)
  for (let num of update.participants) {
    try {
      try {
        ppuser = await junaa.profilePictureUrl(num, 'image')
      } catch {
        ppuser = 'https://telegra.ph/file/265c672094dfa87caea19.jpg'
      }
      if (update.action == 'add') {
        junaa.fetchStatus(num).then(async bio => {
          await junaa.sendMessage(update.id, { image: { url: ppuser }, caption: `*Welcome To ${metadata.subject}*\n\n📛 : _@${num.split("@")[0]}_\n🔢 : _${num.split("@")[0]}_\n💌 : _${bio.status ? bio.status : '-'}_\n🏅 : _${metadata.participants.length ? metadata.participants.length : "Undefined"}_\n📆 : _${moment.tz('Asia/Jakarta').format('dddd')}, ${moment.tz('Asia/Jakarta').format('DD MMMM YYYY')}_\n⏰ : _${moment.tz('Asia/Jakarta').format('HH:mm:ss')} *WIB*_\n\n📄 *Deskripsi :*\n${metadata.desc ? metadata.desc : 'Tidak ada deskripsi'}`, mentions: [num] })
        }).catch(async err => {
          await junaa.sendMessage(update.id, { image: { url: ppuser }, caption: `*Welcome To ${metadata.subject}*\n\n📛 : _@${num.split("@")[0]}_\n🔢 : _${num.split("@")[0]}_\n💌 : _-_\n🏅 : _${metadata.participants.length ? metadata.participants.length : "Undefined"}_\n📆 : _${moment.tz('Asia/Jakarta').format('dddd')}, ${moment.tz('Asia/Jakarta').format('DD MMMM YYYY')}_\n⏰ : _${moment.tz('Asia/Jakarta').format('HH:mm:ss')} *WIB*_\n\n📄 *Deskripsi :*\n${metadata.desc ? metadata.desc : 'Tidak ada deskripsi'}`, mentions: [num] })
        })
      }
    } catch (err) {
      console.log(err)
    }
  }
}

exports.groupResponsePromote = async (junaa, update) => {
  const metadata = await junaa.groupMetadata(update.id)
  for (let num of update.participants) {
    try {
      if (update.action == 'promote') {
        await junaa.sendMessage(update.id, { text: `*@${num.split("@")[0]} Promote From ${metadata.subject}*`, mentions: [num] })
      }
    } catch (err) {
      console.log(err)
    }
  }
}

exports.groupResponseDemote = async (junaa, update) => {
  const metadata = await junaa.groupMetadata(update.id)
  for (let num of update.participants) {
    try {
      if (update.action == 'demote') {
        await junaa.sendMessage(update.id, { text: `*@${num.split("@")[0]} Demote From ${metadata.subject}*`, mentions: [num] })
      }
    } catch (err) {
      console.log(err)
    }
  }
}